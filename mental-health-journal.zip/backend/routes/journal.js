const express = require("express");
const router = express.Router();
const Entry = require("../models/Entry");
const auth = require("../middleware/auth");

// GET all entries
router.get("/", auth, async (req, res) => {
  try {
    const entries = await Entry.find({ user: req.userId }).sort({ date: -1 });
    res.json(entries);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch entries" });
  }
});

// POST new entry
router.post("/", auth, async (req, res) => {
  try {
    const { text, mood } = req.body;
    const entry = await Entry.create({
      text,
      mood,
      user: req.userId,
    });
    res.status(201).json({
      success: true,
      message: "Journal entry added successfully",
      data: entry,
    });
  } catch (err) {
    console.error("Failed to add entry:", err);
    res.status(500).json({ message: "Failed to add entry" });
  }
});

// PUT update entry
router.put("/:id", auth, async (req, res) => {
  try {
    const { text, mood } = req.body;
    const entry = await Entry.findById(req.params.id);

    if (!entry) return res.status(404).json({ message: "Entry not found" });
    if (entry.user.toString() !== req.userId)
      return res.status(401).json({ message: "Unauthorized" });

    entry.text = text || entry.text;
    entry.mood = mood || entry.mood;

    await entry.save();
    res.json({ success: true, message: "Entry updated successfully", data: entry });
  } catch (err) {
    console.error("Failed to update entry:", err);
    res.status(500).json({ message: "Failed to update entry" });
  }
});

// DELETE entry
router.delete("/:id", auth, async (req, res) => {
  try {
    const entry = await Entry.findById(req.params.id);
    if (!entry) return res.status(404).json({ message: "Entry not found" });
    if (entry.user.toString() !== req.userId)
      return res.status(401).json({ message: "Unauthorized" });

    await Entry.findByIdAndDelete(req.params.id);
    res.json({ message: "Entry deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete entry" });
  }
});

module.exports = router;
