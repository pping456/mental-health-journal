// models/Entry.js
const mongoose = require("mongoose");

const entrySchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  text: { type: String, required: true },
  mood: { type: String, required: true },
  date: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Entry", entrySchema);
