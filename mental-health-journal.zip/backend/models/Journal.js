// routes/journalRoutes.js
const express = require("express");
const router = express.Router();
const { addJournalEntry } = require("../controllers/journalController");
const authMiddleware = require("../middleware/authMiddleware");

// protect route
router.post("/", authMiddleware, addJournalEntry);

module.exports = router;
