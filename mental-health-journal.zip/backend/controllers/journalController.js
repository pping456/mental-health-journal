// controllers/journalController.js
const Entry = require("../models/Entry");

const addJournalEntry = async (req, res) => {
  try {
    const { text, mood } = req.body;
    const userId = req.userId; // from auth middleware

    if (!text || !mood) {
      return res.status(400).json({ success: false, message: "Text and mood are required" });
    }

    const newEntry = new Entry({
      user: userId,
      text,
      mood
    });

    await newEntry.save();

    res.status(201).json({
      success: true,
      message: "Journal entry added successfully",
      data: newEntry
    });
  } catch (err) {
    console.error("Failed to add entry:", err);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

module.exports = { addJournalEntry };
