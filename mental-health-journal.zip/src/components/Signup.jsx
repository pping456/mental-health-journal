import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import { handleError, handleSuccess } from '../utils';

function Signup() {
  const [signupInfo, setSignupInfo] = useState({
    name: '',
    email: '',
    password: ''
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSignupInfo({ ...signupInfo, [name]: value });
  };

  const handleSignup = async (e) => {
    e.preventDefault();

    const { name, email, password } = signupInfo;

    if (!name || !email || !password) {
      return handleError("Name, email and password are required");
    }

    try {
      const response = await fetch(
        "http://localhost:5000/api/auth/signup",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(signupInfo)
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || "Signup failed");
      }

      handleSuccess(result.message || "Signup successful 🌸");

      setTimeout(() => navigate("/login"), 1000);

    } catch (err) {
      handleError(err.message || "Server error");
    }
  };

  return (
  <div className="auth-diary">
    
    {/* Optional spiral holes */}
    <div className="spiral-holes">
      <span></span>
      <span></span>
      <span></span>
    </div>

    <h1>🌸 Create Your Cute Journal</h1>

    <form onSubmit={handleSignup}>
      <input
        type="text"
        name="name"
        placeholder="Enter your name..."
        value={signupInfo.name}
        onChange={handleChange}
      />

      <input
        type="email"
        name="email"
        placeholder="Enter your email..."
        value={signupInfo.email}
        onChange={handleChange}
      />

      <input
        type="password"
        name="password"
        placeholder="Enter your password..."
        value={signupInfo.password}
        onChange={handleChange}
      />

      <button type="submit">Signup 🌷</button>
    </form>

    <div className="auth-footer">
      Already have an account? <Link to="/login">Login 🌸</Link>
    </div>

    <ToastContainer />
  </div>
);

}

export default Signup;
