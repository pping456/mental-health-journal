function ThemeToggle({ theme, setTheme }) {
  return (
    <div className="theme-toggle" onClick={() =>
      setTheme(theme === "light" ? "dark" : "light")
    }>
      <div className={`toggle-circle ${theme}`}>
        {theme === "light" ? "☀️" : "🌙"}
      </div>
    </div>
  );
}

export default ThemeToggle;
