function JournalCard({ entry, deleteEntry }) {
  return (
    <div className="journal-card">
      <div className="journal-card-header">
        {/* Display mood */}
        <span className="mood">{entry.mood}</span>

        {/* Delete button */}
        <button className="delete" onClick={() => deleteEntry(entry._id)}>
          ❌
        </button>
      </div>

      {/* Diary text */}
      <p className="journal-text">{entry.text}</p>

      {/* Display formatted date */}
      <small className="journal-date">
        📅 {new Date(entry.date).toLocaleDateString()} 🕒 {new Date(entry.date).toLocaleTimeString()}
      </small>

      {/* Optional diary aesthetic: little rings */}
      <div className="rings">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  );
}

export default JournalCard;
