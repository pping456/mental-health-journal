import React, { useState } from "react";
import axios from "axios";

function JournalList({ entries, deleteEntry, token, updateEntry }) {
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState("");
  const [editMood, setEditMood] = useState("");

  const moods = ["😊 Happy", "😌 Calm", "😢 Sad", "😡 Angry", "😰 Anxious", "😍 Loved"];

  const handleEdit = (entry) => {
    setEditingId(entry._id);
    setEditText(entry.text);
    setEditMood(entry.mood);
  };

  const handleSave = async (id) => {
    try {
      const res = await axios.put(
        `http://localhost:5000/api/journal/${id}`,
        { text: editText, mood: editMood },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      updateEntry(res.data.data);
      setEditingId(null);
    } catch (err) {
      console.error("Failed to update entry:", err.response?.data || err.message);
    }
  };

  if (!entries || entries.length === 0) {
    return <p className="empty">No entries yet. Start writing your cute diary! 🌸</p>;
  }

  return (
    <div className="journal-list" style={{ display: "flex", flexDirection: "column", gap: "16px", marginTop: "20px" }}>
      {entries.map((entry) => (
        <div
          key={entry._id}
          className="journal-card"
          style={{
            backgroundColor: "#f5ebe0",
            border: "2px dotted #d2b48c",
            borderRadius: "20px",
            padding: "16px",
            position: "relative",
            boxShadow: "0 6px 12px rgba(0,0,0,0.08)",
            transition: "transform 0.2s, box-shadow 0.2s",
          }}
        >
          <div className="spiral-holes">
            <span></span>
            <span></span>
            <span></span>
          </div>

          <div className="journal-card-header" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
            {editingId === entry._id ? (
              <select value={editMood} onChange={(e) => setEditMood(e.target.value)}>
                {moods.map((m) => <option key={m} value={m}>{m}</option>)}
              </select>
            ) : (
              <span className="mood" style={{ backgroundColor: "#e0c097", padding: "4px 12px", borderRadius: "12px", fontWeight: "bold" }}>
                {entry.mood}
              </span>
            )}

            <div style={{ display: "flex", gap: "8px" }}>
              {editingId === entry._id ? (
                <button onClick={() => handleSave(entry._id)} className="journal-button">Save</button>
              ) : (
                <button onClick={() => handleEdit(entry)} style={{ cursor: "pointer", fontSize: "14px" }}>✎</button>
              )}
              <button
                className="delete"
                onClick={() => deleteEntry(entry._id)}
                style={{ background: "transparent", border: "none", cursor: "pointer", color: "#8c6d5d", fontSize: "16px" }}
              >
                ✖
              </button>
            </div>
          </div>

          {editingId === entry._id ? (
            <textarea
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              style={{ width: "100%", padding: "8px", borderRadius: "12px", border: "2px dotted #d2b48c" }}
            />
          ) : (
            <p style={{ whiteSpace: "pre-wrap", fontFamily: "'Poppins', sans-serif", color: "#5b3a29" }}>
              {entry.text}
            </p>
          )}

          <small style={{ color: "#8c6d5d", fontSize: "12px" }}>
            {new Date(entry.date).toLocaleString()}
          </small>
        </div>
      ))}
    </div>
  );
}

export default JournalList;
