import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import { handleError, handleSuccess } from '../utils';

function Login({ setToken }) {
  const [loginInfo, setLoginInfo] = useState({
    email: '',
    password: ''
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLoginInfo({ ...loginInfo, [name]: value });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    const { email, password } = loginInfo;

    if (!email || !password) {
      return handleError('Email and password are required');
    }

    try {
      const url = "http://localhost:5000/api/auth/login";

      const response = await fetch(url, {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const result = await response.json();
      const { success, message, token } = result;

      if (success) {
        handleSuccess(message);
        localStorage.setItem('token', token);
        setToken(token);

        setTimeout(() => {
          navigate('/');
        }, 1000);
      } else {
        handleError(message || 'Login failed');
      }
    } catch (err) {
      handleError(err.message || 'Server error');
    }
  };

return (
  <div className="auth-diary">

    <div className="spiral-holes">
      <span></span>
      <span></span>
      <span></span>
    </div>

    <h1>🌼 Welcome Back</h1>

    <form onSubmit={handleLogin}>
      <input
        type="email"
        name="email"
        placeholder="Enter your email..."
        value={loginInfo.email}
        onChange={handleChange}
      />

      <input
        type="password"
        name="password"
        placeholder="Enter your password..."
        value={loginInfo.password}
        onChange={handleChange}
      />

      <button type="submit">Login 🌸</button>
    </form>

    <div className="auth-footer">
      Don’t have an account? <Link to="/signup">Signup 🌷</Link>
    </div>

    <ToastContainer />
  </div>
);


}

export default Login;
