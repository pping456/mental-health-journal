import React, { useState } from "react";
import axios from "axios";

const moods = ["😊 Happy", "😌 Calm", "😢 Sad", "😡 Angry", "😰 Anxious", "😍 Loved"];

function JournalForm({ addEntry, token, handleLogout }) {
  const [text, setText] = useState("");
  const [mood, setMood] = useState(moods[0]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!text) return;

    setLoading(true);
    setError(null);

    try {
      const res = await axios.post(
        "http://localhost:5000/api/journal",
        { text, mood },
        { headers: { Authorization: `Bearer ${token}` } } // send token
      );

      addEntry(res.data.data || res.data); // backend returns { data } or entry directly
      setText("");
      setMood(moods[0]);
    } catch (err) {
      if (err.response) {
        if (err.response.status === 401) {
          setError("Session expired. Please login again.");
        } else {
          setError(err.response.data.message || "Something went wrong. Please try again.");
        }
      } else if (err.request) {
        setError("Server did not respond. Try again later.");
      } else {
        setError("An unexpected error occurred.");
        console.error("Unexpected error adding entry:", err);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="journal-form-container"
      style={{
        maxWidth: "600px",
        margin: "30px auto",
        padding: "30px 25px",
        backgroundColor: "#f5ebe0",
        border: "2px dashed #d2b48c",
        borderRadius: "24px",
        boxShadow: "0 6px 20px rgba(0,0,0,0.08)",
        fontFamily: "Poppins, sans-serif",
        position: "relative",
      }}
    >
      {/* Spiral Holes */}
      <div className="spiral-holes" style={{ display: "flex", gap: "12px", position: "absolute", top: "-12px", left: "20px" }}>
        <span style={{ width: "12px", height: "12px", backgroundColor: "#fff", border: "2px solid #d2b48c", borderRadius: "50%", boxShadow: "0 2px 4px rgba(0,0,0,0.1)" }}></span>
        <span style={{ width: "12px", height: "12px", backgroundColor: "#fff", border: "2px solid #d2b48c", borderRadius: "50%", boxShadow: "0 2px 4px rgba(0,0,0,0.1)" }}></span>
        <span style={{ width: "12px", height: "12px", backgroundColor: "#fff", border: "2px solid #d2b48c", borderRadius: "50%", boxShadow: "0 2px 4px rgba(0,0,0,0.1)" }}></span>
      </div>

      <h1 style={{ textAlign: "center", color: "#8c6d5d" }}>🌸 Mental Health Journal </h1>
      {error && <p style={{ color: "red", textAlign: "center" }}>{error}</p>}

      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "12px", alignItems: "center" }}>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Write your thoughts..."
          required
          disabled={loading}
          style={{ width: "95%", padding: "12px", borderRadius: "20px", border: "2px dotted #d2b48c", resize: "vertical", backgroundColor: "#fff8f0", fontFamily: "Poppins, sans-serif" }}
        />

        <select
          value={mood}
          onChange={(e) => setMood(e.target.value)}
          disabled={loading}
          style={{ width: "95%", padding: "12px", borderRadius: "20px", border: "2px dotted #d2b48c", backgroundColor: "#fff8f0" }}
        >
          {moods.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>

        <button
          type="submit"
          disabled={loading || !text}
          style={{
            width: "50%",
            padding: "12px",
            borderRadius: "20px",
            backgroundColor: loading ? "#ccc" : "#e0c097",
            cursor: loading ? "not-allowed" : "pointer",
            fontWeight: "bold",
            border: "none",
          }}
        >
          {loading ? "Adding..." : "Add Entry 🌸"}
        </button>

        {/* Logout button under mood section */}
        {handleLogout && (
          <button
            type="button"
            onClick={handleLogout}
            style={{
              width: "50%",
              padding: "12px",
              borderRadius: "20px",
              backgroundColor: "#d2b48c",
              marginTop: "10px",
              border: "none",
              fontWeight: "bold",
              cursor: "pointer",
              color: "#3e2f2f",
            }}
          >
            Logout
          </button>
        )}
      </form>
    </div>
  );
}

export default JournalForm;
