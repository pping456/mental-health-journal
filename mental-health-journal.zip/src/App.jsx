import { useEffect, useState } from "react";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";
import axios from "axios";

import JournalForm from "./components/JournalForm";
import JournalList from "./components/JournalList";
import ThemeToggle from "./components/ThemeToggle";
import Login from "./components/Login";
import Signup from "./components/Signup";

import "./styles.css";
import "./Diary.css";

/* 🔐 Protected Route */
function ProtectedRoute({ token, children }) {
  return token ? children : <Navigate to="/login" replace />;
}

function App() {
  const [entries, setEntries] = useState([]);
  const [theme, setTheme] = useState("light");
  const [token, setToken] = useState(localStorage.getItem("token"));
  const navigate = useNavigate();

  /* ✅ Set Axios JWT Header */
  useEffect(() => {
    if (token) {
      axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    } else {
      delete axios.defaults.headers.common["Authorization"];
    }
  }, [token]);

  /* 📥 Fetch entries for logged-in user */
  const fetchEntries = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/journal");
      setEntries(res.data); // backend returns array of entries
    } catch (err) {
      console.log("Error fetching entries:", err.response?.data || err.message);
    }
  };

  /* 🌱 Initial load */
  useEffect(() => {
    if (token) fetchEntries();

    const savedTheme = localStorage.getItem("theme");
    if (savedTheme) setTheme(savedTheme);
  }, [token]);

  /* 🌙 Theme switcher */
  useEffect(() => {
    document.body.className = theme;
    localStorage.setItem("theme", theme);
  }, [theme]);

  /* ➕ Add entry */
  const addEntry = async (entry) => {
    try {
      const res = await axios.post(
        "http://localhost:5000/api/journal",
        entry,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setEntries((prev) => [res.data.data || res.data, ...prev]);
    } catch (err) {
      console.log("Error adding entry:", err.response?.data || err.message);
    }
  };

  /* ❌ Delete entry */
  const deleteEntry = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/journal/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEntries((prev) => prev.filter((e) => e._id !== id));
    } catch (err) {
      console.log("Error deleting entry:", err.response?.data || err.message);
    }
  };

  /* ✏️ Update entry */
  const updateEntry = (updatedEntry) => {
    setEntries((prev) =>
      prev.map((e) => (e._id === updatedEntry._id ? updatedEntry : e))
    );
  };

  /* 🔐 Handle logout */
  const handleLogout = () => {
    localStorage.removeItem("token");
    setToken(null);
    navigate("/login");
  };

  return (
    <Routes>
      {/* 🌸 Authentication */}
      <Route
        path="/login"
        element={!token ? <Login setToken={setToken} /> : <Navigate to="/" />}
      />
      <Route
        path="/signup"
        element={!token ? <Signup setToken={setToken} /> : <Navigate to="/" />}
      />

      {/* 📔 journal Dashboard */}
      <Route
        path="/"
        element={
          <ProtectedRoute token={token}>
            <div className="app">
              <div className="theme-wrapper">
                <ThemeToggle theme={theme} setTheme={setTheme} />
              </div>

              {/* ✅ Pass token and handleLogout to JournalForm */}
              <JournalForm addEntry={addEntry} token={token} handleLogout={handleLogout} />

              {/* Journal entries with CRUD */}
              <JournalList
                entries={entries}
                deleteEntry={deleteEntry}
                updateEntry={updateEntry} // ✅ Pass update function
                token={token} // ✅ Pass token for edit API
              />
            </div>
          </ProtectedRoute>
        }
      />

      {/* 🔄 Redirect unknown paths */}
      <Route path="*" element={<Navigate to={token ? "/" : "/login"} replace />} />
    </Routes>
  );
}

export default App;
